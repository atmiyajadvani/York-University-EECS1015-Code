################
# Lab 4
# Author: Atmiya Jadvani
# Email: atmiya@my.yorku.ca
# Student ID: 219164888
# Section A
###############

# you'll need the random module
import random


# Write your functions below #

# function will return a random number between 2-14.
def getCardValue():
    cardValue = random.randint(2, 14)
    return cardValue


# function will convert the integer to a string
def getCardStr(cardValue):
    if 2 <= cardValue <= 9:
        cardValue = str(cardValue)
    elif cardValue == 10:
        cardValue = "T"
    elif cardValue == 11:
        cardValue = "J"
    elif cardValue == 12:
        cardValue = "Q"
    elif cardValue == 13:
        cardValue = "K"
    elif cardValue == 14:
        cardValue = "A"
    return cardValue


# function will repeatedly ask the player "High or Low (H/L)?:"
def getHLGuess():
    userGuess = input("High or Low (H/L)?: ").upper()
    while userGuess != "H" and userGuess != "L":
        userGuess = input("High or Low (H/L)?: ").upper()

    if userGuess == "H":
        return "HIGH"
    elif userGuess == "L":
        return "LOW"


# function will repeatedly ask the player "Input bet amount: "
def getBetAmount(maximum):
    betAmount = int(input("Input bet amount: ").strip())
    while betAmount < 1 or betAmount > maximum:
        betAmount = input("Input bet amount: ").strip()
    return betAmount


# function returns True or False (Boolean) depending on if the guess was right.
def playerGuessCorrect(card1, card2, betType):
    if betType == "HIGH":
        if card1 < card2:
            return True
        else:
            return False
    elif betType == "LOW":
        if card1 > card2:
            return True
        else:
            return False


# Write your main program below ####
msg = """--- Welcome to High-Low ---
Start with 100 points.  Each round a card will be drawn and shown.
Select whether you think the 2nd card will be Higher or Lower than the 1st card.
Then enter the amount you want to bet.
If you are right, you win the amount you bet, otherwise you lose. 
Try to make it to 500 points within 10 tries."""

print(msg)

# Set initial points to 100 and round to 1
roundNumber = 0
overallPoints = 100

#  While the gameplay is valid (i.e., stopping criteria not reached)
while overallPoints < 500 and roundNumber < 10:

    if overallPoints > 0:
        # Adding 1 when the rounds progresses
        roundNumber = roundNumber + 1

        print("------------------------------------------")

        # Show the current amount of points and what round it is
        print(f"OVERALL POINTS: {overallPoints} ROUND {roundNumber}/10")

        # Get the first card, print out its string value
        cardValue1 = getCardValue()
        cardNo1 = getCardStr(cardValue1)
        print(f"First card is a [{cardNo1}]")

        # Get the players High/Low guess
        typeOfBet = getHLGuess()

        # Get the players bet
        userBet = getBetAmount(overallPoints)

        # Get the second card, print out its string value
        cardValue2 = getCardValue()
        cardNo2 = getCardStr(cardValue2)
        print(f"Second card is a [{cardNo2}]")

        # Check to see if players guess was correct
        playerGuess = playerGuessCorrect(cardNo1, cardNo2, typeOfBet)

        # If the guess was True, the bet is added to the overall points; otherwise, deduct the bet amount
        result = "WON"
        if playerGuess == True:
            result = "WON"
        else:
            result = "LOSE"

        # Printout the round result
        print(f"Card 1 [{cardNo1}], Card 2 [{cardNo2}] - You bet '{typeOfBet}' for {userBet} - YOU {result} ")

        # Updating the points
        if playerGuess == True:
            overallPoints = overallPoints + userBet
        else:
            overallPoints = overallPoints - userBet

    else:
        break

if overallPoints >= 500:
    print("-------------------WIN--------------------")
    print(f"YOU MADE IT TO *{overallPoints}* POINTS IN {roundNumber} ROUNDS!")
    print("------------------------------------------")
elif overallPoints < 500:
    print("-------------------LOSE-------------------")
    print(f"ONLY *{overallPoints}* in {roundNumber} ROUNDS!")
    print("------------------------------------------")
elif overallPoints == 0:
    print("-------------------LOSE-------------------")
    print(f"YOU HAVE *{overallPoints}* AFTER {roundNumber} ROUNDS!")
    print("------------------------------------------")

# input statement to pause code when finished
input("Press enter to exit. ")
