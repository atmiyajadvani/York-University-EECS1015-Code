################
# Lab 2
# Author: Atmiya Jadvani
# Email: atmiya@my.yorku.ca
# Student ID: 219164888
# Section A
###############


print("\n----Task 1---- BMI Calculator")
# taking the inputs
name = input("name: ").strip().title()
weight_in_kilograms = float(input("weight (Kg) : ").strip())
height_in_centimeters = float(input("height (cm): ").strip())

# Conversions and Calculations
height_in_meters = float(height_in_centimeters / 100)
bmi = (weight_in_kilograms / height_in_meters ** 2)

# Decimal Formatting
formated_weight_in_kilograms = format(weight_in_kilograms, '.2f')
formated_height_in_meters = format(height_in_meters, '.2f')
formated_bmi = format(bmi, '.2f')

result = f"Name: {name}, Weight: {formated_weight_in_kilograms}, Height [meters]: {formated_height_in_meters}, Your BMI: {formated_bmi}"
print(result)

###########################################################################


print("\n----Task 2---- Leetspeak Converter")
# Taking the input
long_string = input("Type a long string: ").strip().upper()

# String formatting
leetspeak = long_string.replace("T", "+").replace("A", "@").replace("E", "3").replace("I", "|").replace("B", "8") \
    .replace("O", "0").replace("C", "[").replace("S", "5")  # the new string

print(leetspeak)

###########################################################################


print("\n----Task 3---- Flipping String")
# Taking the input
long_string = input("Input a long string:").strip().upper()

# Calculations
length_of_string = len(long_string)
middle_character = long_string[int(length_of_string / 2)]
string1 = long_string[: int(length_of_string / 2)]
string2 = long_string[int(length_of_string / 2):]
flipped_string = string2 + " | " + string1

print(f"This string is {length_of_string} characters long. The middle character is '{middle_character}'")
print(f"flipped_string\n {flipped_string}")

###########################################################################


print("\n----Task 4---- Multiple numbers")
# Taking the input
enter_numbers = input("Input numbers to multiply: ").strip().replace(" ", "").replace("*", " ").split()

# Calculations
number_1 = int(enter_numbers[0])
number_2 = int(enter_numbers[1])
result = number_1 * number_2

print(f"Extracted numbers are {number_1} and {number_2}")
print(result)

input("Press enter to exit")
