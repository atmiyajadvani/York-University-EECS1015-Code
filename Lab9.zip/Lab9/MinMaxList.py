# Lab 9
# Author: Atmiya Jadvani
# Email: atmiya@my.yorku.ca
# Student ID: 219164888
# Section A

class MinMaxList:

    def __init__(self, listData):
        self.listData = listData
        self.listData.sort()

    def insertItem(self, item, printResult: bool):
        lengthOfList = len(self.listData)
        index = 0

        if lengthOfList == 0:
            self.listData.append(item)
        elif self.listData[lengthOfList - 1] <= item:
            self.listData.append(item)
        else:
            for index in range(lengthOfList):
                if self.listData[index] > item:
                    break
            self.listData.insert(index, item)

        print(f"Item ({str(item)}) Inserted at location {str(index)}")
        if printResult:
            self.printList()

    def getMin(self):
        minElement = self.listData[0]
        self.listData.remove(minElement)
        return minElement

    def getMax(self):
        length = len(self.listData)
        maxElement = self.listData[length - 1]
        self.listData.remove(maxElement)
        return maxElement

    def printList(self):
        print(self.listData)