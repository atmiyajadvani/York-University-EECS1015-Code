###########################################
# EECS1015 - Final exam (final.py)
# Name: Atmiya Jadvani
# Student ID: 219164888
# Email: atmiya@my.yorku.ca
# Section A
###########################################

from random import randint as randomInteger
from utilities import *
import time


def task0():
    print("Final Exam - EECS1015")
    print("Name: Atmiya Jadvani")
    print("Student ID: 219164888")
    print("Email: atmiya@my.yorku.ca")
    print("Section A")


###########################################################################################

# function prints the outcomes depending on the selections
def printOutcome(userSelection, computerSelection):
    if userSelection == "rock" and computerSelection == "scissors":
        print("You win!")
    elif userSelection == "rock" and computerSelection == "paper":
        print("HAL wins!")
    elif userSelection == "rock" and computerSelection == "rock":
        print("A tie!")
    elif userSelection == "paper" and computerSelection == "rock":
        print("You win!")
    elif userSelection == "paper" and computerSelection == "scissors":
        print("HAL wins!")
    elif userSelection == "paper" and computerSelection == "paper":
        print("A tie!")
    elif userSelection == "scissors" and computerSelection == "paper":
        print("You win!")
    elif userSelection == "scissors" and computerSelection == "rock":
        print("HAL wins!")
    elif userSelection == "scissors" and computerSelection == "scissors":
        print("A tie!")


def task1():
    print("Rock, Paper, Scissors!")
    print("Make your selection. . .")

    # Get input from user
    userInput = int(input("(1) rock, (2) paper, (3) scissors?: ").strip())

    # Sentinel Controlled Loop
    while userInput > 3 or userInput < 1:
        print("Invalid selection. Try again.")
        userInput = int(input("(1) rock, (2) paper, (3) scissors?: ").strip())

    # Computer's Choice
    halChoice = randomInteger(1, 3)

    # Print out the user's selection and HAL's selection
    if userInput == 1:
        userInput = "rock"
    elif userInput == 2:
        userInput = "paper"
    elif userInput == 3:
        userInput = "scissors"

    if halChoice == 1:
        halChoice = "rock"
    elif halChoice == 2:
        halChoice = "paper"
    elif halChoice == 3:
        halChoice = "scissors"

    print(f"You: {userInput}")
    print(f"HAL: {halChoice}")

    printOutcome(userInput, halChoice)

    # Want to play again?
    playAgain = input("Play again (Y/N)?: ").strip().upper()
    if playAgain == "Y":
        task1()
    else:
        pass


###########################################################################################


# The function should modify the list ( Swapped list items )
def swapAdjacentElements(aList):
    assert len(aList) >= 2, "Must enter two or more characters!"

    for item in range(len(aList)):
        if item % 2 != 0:
            # Swapping the elements in the list
            priorElement = aList[item]
            aList[item] = aList[item - 1]
            aList[item - 1] = priorElement
    print(aList)


def task2():
    empty = ""

    # Prompt the user to input a sequence of two or more characters separated by spaces.
    userInput = input("Input two or more chars separated by spaces: ").strip()
    inputList = userInput.split()
    print("Initial list")
    print(inputList)
    noSpaceInputList = empty.join(inputList)
    print(f"String version: '{noSpaceInputList}'")

    # Modified Listß
    print("Modified list")
    swapAdjacentElements(inputList)
    noSpaceModifiedList = empty.join(inputList)
    print(f"String version: '{noSpaceModifiedList}'")


###########################################################################################

# what year a student is studying
def year(index):
    for studentYear in studentsInfo:
        if studentYear == "Year 1" or studentYear == "Year 2" or studentYear == "Year 3" or studentYear == "Year 4":
            for j in studentsInfo[studentYear]:
                if j == index:
                    return studentYear


# indicate the students' program of study
def program(index):
    for studentMajor in studentsInfo:
        if studentMajor == "CS" or studentMajor == "DM" or studentMajor == "BZ" or studentMajor == "SE":
            for j in studentsInfo[studentMajor]:
                if j == index:
                    return studentMajor


# indicate the students' living arrangements
def housing(index):
    for campus in studentsInfo:
        if campus == "On Campus" or campus == "Off Campus":
            for j in studentsInfo[campus]:
                if j == index:
                    return campus


# Finding the student's index
def findIndex(student):
    for studentIndex in range(len(students)):
        if students[studentIndex] == student:
            return studentIndex


def task3():
    for i in sorted(students):
        index = findIndex(i)
        print(f"{'%10s' % i} ({year(index)}) Program: {program(index)} Housing: {housing(index)}")


###########################################################################################

def task4():
    userInput = input("Press enter to start aquarium.")

    # Create a list of five SeaLife objects
    seaLifeAnimals = []
    for i in range(0, 5):
        startingPosition = randomInteger(5, 30)
        startingDirection = randomInteger(0, 1)
        seaLifeAnimals.append(SeaLife(startingDirection, startingPosition))

    # Time step counter
    timeStep = 1

    # Printing out the aquarium 50 times
    for i in range(0, 50):
        # Print out the current time step
        print('-' * 40 + 'Time:' + str(timeStep))
        for animals in seaLifeAnimals:
            print(animals.getStr())
            animals.move()
            time.sleep(0.3)
        timeStep += 1


###########################################################################################


def main():
    print("\n--------- Task0: Submission Info       ------------")
    task0()
    print("\n--------- Task1: Rock, Paper, Scissors ------------")
    task1()
    print("\n--------- Task2: Swap List Elements    ------------")
    task2()
    print("\n--------- Task3: Student Info          ------------")
    task3()
    print("\n--------- Task4: Aquarium              ------------")
    task4()

    input("Press enter to quit.")


if __name__ == "__main__":
    main()
