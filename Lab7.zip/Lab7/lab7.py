#########################
# EECS1015 - York University
# Lab #7
# Author: Atmiya Jadvani
# Email: atmiya@yorku.ca
# Student ID: 219164888

#  Writing test cases
#  Make sure you install PyTest (see lecture notes)
#  NOTE - You can only run this in PyCharm for a project that has installed PyTest
#  You cannot double click on this file.  That is fine, we can test it once you submit it.
#########################

import pytest
from typing import List


# Accepts a list of integers
def initializeMinMaxList(myList: List[int]) -> None:  # given
    myList.sort()


def insertItem(myList: List[int], item: int) -> None:  # given
    myList.append(item)
    myList.sort()


def getMinMax(myList: List[int], minormax: str) -> int:  # given -- but requires additional assert
    assert len(myList) != 0, "The list must not be empty" # check the pre-condition that the list is not empty.
    assert minormax.upper() == "MAX" or minormax.upper() == "MIN", "2nd argument must be 'Min' or 'Max' "
    result: int
    if minormax == "MAX":
        result = myList[-1]
        del myList[-1]
    else:
        result = myList[0]
        del myList[0]
    return result


# Main function is given.
def main():
    aList = [10, 11, 99, 1, 55, 100, 34, 88]
    print("Starting List: ", aList)
    initializeMinMaxList(aList)
    min1 = getMinMax(aList, "MIN")
    print("1st min: %d" % (min1))
    min2 = getMinMax(aList, "MIN")
    print("2nd min: %d" % (min2))
    max1 = getMinMax(aList, "MAX")
    print("1st max: %d" % (max1))
    max2 = getMinMax(aList, "MAX")
    print("2nd max: %d" % (max2))

    print("Insert %d %d %d %d" % (min1 - 1, min2 - 1, max1 + 1, max2 + 1))
    insertItem(aList, min1 - 1)
    insertItem(aList, min2 - 1)
    insertItem(aList, max1 + 1)
    insertItem(aList, max2 + 1)

    min1 = getMinMax(aList, "MIN")
    print("1st min: %d" % (min1))
    min2 = getMinMax(aList, "MIN")
    print("2nd min: %d" % (min2))
    max1 = getMinMax(aList, "MAX")
    print("1st max: %d" % (max1))
    max2 = getMinMax(aList, "MAX")
    print("2nd max: %d" % (max2))

    print("DONE.  Type Enter to exit.")
    input()


if __name__ == "__main__":
    main()


#####
# WRITE YOUR TEST CASES BELOW HERE
#
######

# function will test a standard use case for our MinMaxList.
def test_getMinMaxCase1():
    list1 = [2, 4]
    initializeMinMaxList(list1)
    x = getMinMax(list1, "MIN")
    assert x == 2, "Min should be 12"
    y = getMinMax(list1, "MAX")
    assert y == 4, "Max should be 6"


# function will test an edge case where the list only has a single item.
def test_getMinMaxCase2():
    y = [8]
    initializeMinMaxList(y)
    minTest = getMinMax(y, "MIN")
    assert minTest == 8, "Min should be 8"
    insertItem(y, 8)
    maxTest = getMinMax(y, "MAX")
    assert maxTest == 8, "Max should be 8"


# function will test an edge case where the list starts out empty.
def test_getMinMaxCase3():
    emptyList = []
    initializeMinMaxList(emptyList)
    insertItem(emptyList, 2)
    insertItem(emptyList, 4)
    minTest = getMinMax(emptyList, "MIN")
    assert minTest == 2, "Min should be 2"
    maxTest = getMinMax(emptyList, "MAX")
    assert maxTest == 4, "Max should be 4"


# function will test to see if getMinMax() properly causes an assertion error when the string argument is not correct.
def test_getMinMaxRequestError():
    with pytest.raises(AssertionError) as e:
        exampleList = [4, 9, 20]
        initializeMinMaxList(exampleList)
        result = getMinMax(exampleList, "MID")
        assert e.typename == "AssertionError", "Should raise AssertionError!"


# function will test to see if getMinMax() properly causes an assertion error when the list is empty.
def test_getMinMaxEmptyError():
    with pytest.raises(AssertionError) as e:
        anotherList = []
        initializeMinMaxList(anotherList)
        result = getMinMax(anotherList, "MIN")
        assert e.typename == "AssertionError", "Should raise AssertionError!"


