
from random import randint

# function to get a key press
def pressEnter (prompt="Press Enter: "):
    input(prompt)

# simple function to simulate a dice roll
# it returns a value between 1-6
def rollDice():
    result = randint(1,6)
    return result

# function to check it player wants to play again
# this modifies the global variable keepPlaying
def keepPlaying():
    global keepPlaying
    str = input("Play again? (Y/N): ")
    if str.upper()=="Y":
        keepPlaying = True
    else:
        keepPlaying = False

# function to see who won and print out the results
def checkGameResults(playerDice,computerDice):
    print("--------------------------------")
    if playerDice < computerDice:
        print("Computer's larger - You LOSE!")
    elif playerDice > computerDice:
        print("Your dice is larger - You WIN!")
    else:
        print("Both dices are same - You TIE!")
    print("--------------------------------")

#Printing the dice value
def printDice (dice, message=""):
    if message != "":
        print(message)

    if dice == 1:
        print("Dice value: 1")
    elif dice == 2:
        print("Dice value: 2")
    elif dice == 3:
        print("Dice value: 3")
    elif dice == 4:
        print("Dice value: 4")
    elif dice == 5:
        print("Dice value: 5")
    elif dice == 6:
        print("Dice value: 6")


def main():
    # define a global variable
    global keepPlaying
    keepPlaying = True
    print("---> TRY TO ROLL HIGHER THAN THE COMPUTER! <---")

    while(keepPlaying):
        pressEnter("Press enter to roll your dice!")
        yourDice = rollDice()
        printDice(yourDice, "YOUR ROLL!")
        pressEnter("Press enter to let the computer roll! ")
        computerDice = rollDice()
        printDice(computerDice, "COMPUTER'S ROLL")
        checkGameResults(yourDice, computerDice)
        playAgain()  # modifies the keepPlaying global

        print("Thanks for playing!")  # end of main()


# main entry point of program.
# Check if this is the main program
# if so, call the main function
if __name__ == "__main__":
main()











