# data for student grades and info
studentGrades = {"Artyom": [84, 90, 77, 84],
                 "Aditi": [88, 78, 65, 90],
                 "Jiatao": [67, 88, 90, 100],
                 "Rutha": [70, 71, 77, 78],
                 "Sayed": [88, 87, 77, 81],
                 "Yunjo": [88, 81, 80, 76]}

studentId = {"Artyom": 304303,
             "Aditi": 343999,
             "Jiatao": 333430,
             "Rutha": 300993,
             "Sayed": 332930,
             "Yunjo": 303300}

gradeItems = ["Lab 1", "Lab 2", "Midterm", "Final"]


# defining the classes
class Student:
    def __init__(self, name, id):
        self.name = name
        self.id = id
        self.grades = {}

    def addGrade(self, gradeName, marks):
        self.grades[gradeName] = marks

    def printGrades(self):
        print(f"Student: {self.name}, ID:{self.id}")
        for item, mark in self.grades.items():
            print(f"Grade: {mark}, Item: {item}")


# Helper function that takes a list of student objects
def printStudentGrades(studentList):
    for student in studentList:
        student.printGrades()


def main():
    global studentGrades, gradeItems, studentId

    # create a list of student objects using the global variables
    studentList = []
    for name, gradeList in studentGrades.items():
        newStudent = Student(name, studentId[name])
        n = len(gradeItems)
        for i in range(n):
            newStudent.addGrade(gradeItems[i], gradeList[i])
        studentList.append(newStudent)

    # print the studentList of student objects
    printStudentGrades(studentList)

