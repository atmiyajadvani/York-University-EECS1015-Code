##############################
# Lab3
# Author name: Atmiya Jadvani
# Student ID: 219164888
# Email address: atmiya@my.yorku.ca
# Section A
##############################


# Code for task 1 after this line
print("\n--- Task 1 ---: Compute Fare")

# Taking user inputs
fare_type = int(input("(1) One way or (2) round trip? \nEnter 1 or 2: "))
age_group = int(input("Select Age Range: \n(1) under 12 \n(2) 13-64 \n(3) 65 or older \nEnter 1, 2, or 3: "))
fare_amount = 1
discounted_fare_amount = 1

# Considering the faretype
if fare_type == 1:
    fare_amount = 1.80
elif fare_type == 2:
    fare_amount = 3.50

# Giving respective discounts
if age_group == 1 or age_group == 3:
    discounted_fare_amount = (float(fare_amount)/2)

formated_fare_amount = format(fare_amount, ".2f")
discounted_fare_amount = format(discounted_fare_amount,".2f")

# Printing statements
if fare_type == 1 and age_group == 2:
    print(f"Total amount due: ${formated_fare_amount} [one way (full fare)]")
if fare_type == 2 and age_group == 2:
    print(f"Total amount due: ${formated_fare_amount} [round trip (full fare)]")
if fare_type == 1 and (age_group == 1 or age_group == 3):
    print(f"Total amount due: ${discounted_fare_amount} [one way (reduced fare)]")
if fare_type == 2 and (age_group == 1 or age_group == 3):
    print(f"Total amount due: ${discounted_fare_amount} [round trip (reduced fare)]")


##############################

# Code for task 2 after this line
print("\n--- Task 2 ---: Parse string")

# Taking the input string
input_string = input("Enter a long string: ").strip()


# Printing out characters
for i in range(0,len(input_string)):
    if input_string[i] == " ":
        print(f"str[{i}] = SPACE")
    else:
        print(f"str[{i}] = {input_string[i]}")

# Printing string in reverse
reversed_string = input_string[::-1].replace(" " , "")
print(f"Reverse no spaces: {reversed_string}")


##############################


# Code for task 3 after this line
print("\n--- Task 3 ---: The maximum *even* number")

# Defining the variables for comparison
integer = 0
max = 0
print("Keep entering positive integer. \nTo quit, input a negative integer")

# Logic
while integer >= 0:
    integer = int(input("Enter a number: "))
    if integer >= max and integer % 2 == 0:
        max = integer

if max == 0:
    print(f"Largest even integer: {max} <- No even number was provided")
else:
    print(f"Largest even integer: {max}")



##############################

# Code for task 4 after this line
print("\n--- Task 4 ---: Better triangle draw")

# Asking integer input from the user
rows = int(input("Enter size between 5 and 20: ").strip())
output = 0

while rows < 5 or rows > 20:
    rows = int(input("Enter size between 5 and 20: ").strip())

# Drawing upper triangle
for rows in range(0, rows):
    for columns in range(0, rows):
        print("-", end="" )
    print("\\")

print(((rows+1) * "-") + "|")

# Drawing lower triangle
for rows in range(rows, -1, -1):
    for columns in range(0, rows+1):
        if columns > 0:
            print("-", end="")
    print("/")



#######

input("Press enter to quit.")