####
# EECS1015 - Midterm
# Name: Atmiya Jadvani
# Student ID: 219164888
# Email: atmiya@my.yorku.ca
# Section A
#####

import random

def task0():
    # My Information
    print("Midterm Exam - EECS1015")
    print("Name: Atmiya Jadvani")
    print("Student ID: 219164888")
    print("email: atmiya@my.yorku.ca")
    print("Section A")


def task1():
    # User's first and last name
    firstName = input("Your first name: ").strip().title()
    lastName = input("Your last name: ").strip().upper()

    # User's initial amount of funds and annual return
    initialFunds = float(input("Initial funds to invest: $").strip())
    annualReturn = float(input("Annual return percentage: ").strip())
    year = 0
    annualAmountNew = 0

    print(f"Yearly return for {firstName} {lastName}")
    print(f"Initial deposit: ${initialFunds:.2f}")

    # Printing compound return for 5 years
    while year < 5:
        year = year + 1
        initialFunds = initialFunds + initialFunds * (annualReturn / 100)
        annualAmountNew = annualAmountNew + initialFunds
        print(f"Year {year}: ${initialFunds:.2f}")


def task2():
    # defining variables
    currentAmount = float(0.00)
    totalAmount = float(1.00)
    tonnie = float(2.00)
    lonnie = float(1.00)
    quarter = float(0.25)
    dime = float(0.10)
    nickel = float(0.05)

    # Welcome Message
    print("Soda Vending Machine")
    print(f"Current amount ${currentAmount:.2f} out of $1.00")
    print("""Insert Coin\n1. Toonie  ($2.00)\n2. Loonie  ($1.00)\n3. Quarter ($0.25)\n4. Dime    ($0.10)\n5. Nickel  ($0.05)""")
    selection = int(input("Selection [1-5]?: ").strip())

    # Loop runs until the currentAmount > totalAmount
    while currentAmount < totalAmount:

        # Sentinel Controlled Python Loop
        if selection < 1 or selection > 5:
            print("Invalid Selection.")
            print(f"Current amount ${currentAmount:.2f} out of $1.00")
            print(
                """Insert Coin\n1. Toonie  ($2.00)\n2. Loonie  ($1.00)\n3. Quarter ($0.25)\n4. Dime    ($0.10)\n5. Nickel  ($0.05)""")
            selection = int(input("Selection [1-5]?: ").strip())

        # If user selected option 1
        elif selection == 1:
            currentAmount = currentAmount + tonnie
            change = currentAmount - totalAmount
            print(f"Total amount provided: ${currentAmount:.2f}")
            print("Thank you for your purchase.")
            print(f"Please take your change ${change:.2f}")

        # If user selected option 2,3,4,5
        elif selection == 2 or selection == 3 or selection == 4 or selection == 5:
            if selection == 2:
                currentAmount = currentAmount + lonnie
            elif selection == 3:
                currentAmount = currentAmount + quarter
            elif selection == 4:
                currentAmount = currentAmount + dime
            elif selection == 5:
                currentAmount = currentAmount + nickel

            change = currentAmount - totalAmount

            # logic between current amount and total amount
            if currentAmount > totalAmount:
                print(f"Total amount provided: ${totalAmount:.2f}")
                print("Thank you for your purchase.")
                print(f"Please take your change ${change:.2f}")
            elif currentAmount == totalAmount:
                print(f"Total amount provided: ${totalAmount:.2f}")
                print("Thank you for your purchase.")
            elif currentAmount < totalAmount:
                print(f"Current amount ${currentAmount:.2f} out of $1.00")
                print(
                    """Insert Coin\n1. Toonie  ($2.00)\n2. Loonie  ($1.00)\n3. Quarter ($0.25)\n4. Dime    ($0.10)\n5. Nickel  ($0.05)""")
                selection = int(input("Selection [1-5]?: ").strip())



def task3():
    # Defining Variables
    totalAmount = 0
    numberOne = 0
    print("Dice Game \nRolling Die 10 times")

    # Rolling the die, 10 times
    for i in range(1, 11):
        dieRoll = random.randint(1, 6)
        print(f"Roll {i}: [{dieRoll}]")
        totalAmount = totalAmount + dieRoll
        if dieRoll == 1:
            numberOne = numberOne + 1

    # The conditional logic
    if totalAmount > 35 and numberOne != 2:
        print(f"Total {totalAmount} -- OVER 35 POINTS [YOU WIN!]")
    elif totalAmount <= 35 and numberOne != 2:
        print(f"Total {totalAmount} -- TOO FEW POINTS [YOU LOSE!]")
    elif totalAmount > 35 and numberOne == 2:
        print("+10 Bonus for snake eyes [1][1]!")
        totalAmount = totalAmount + 10
        print(f"Total {totalAmount} -- OVER 35 POINTS [YOU WIN!]")
    elif totalAmount <= 35 and numberOne == 2:
        print("+10 Bonus for snake eyes [1][1]!")
        totalAmount = totalAmount + 10
        if totalAmount > 35:
            print(f"Total {totalAmount} -- OVER 35 POINTS [YOU WIN!]")
        elif totalAmount <= 35:
            print(f"Total {totalAmount} -- TOO FEW POINTS [YOU LOSE!]")

    # Asking the user if he/she wants to continue
    answer = str(input("Enter 'Y' to play again: ").strip().upper())

    # Everytime the answer == "Y", this loop continues
    while answer == "Y":
        totalAmount = 0
        numberOne = 0
        print("Dice Game \nRolling Die 10 times")

        for i in range(1, 11):
            dieRoll = random.randint(1, 6)
            print(f"Roll {i}: [{dieRoll}]")
            totalAmount = totalAmount + dieRoll
            if dieRoll == 1:
                numberOne = numberOne + 1

        if totalAmount > 35 and numberOne != 2:
            print(f"Total {totalAmount} -- OVER 35 POINTS [YOU WIN!]")
        elif totalAmount <= 35 and numberOne != 2:
            print(f"Total {totalAmount} -- TOO FEW POINTS [YOU LOSE!]")
        elif totalAmount > 35 and numberOne == 2:
            print("+10 Bonus for snake eyes [1][1]!")
            totalAmount = totalAmount + 10
            print(f"Total {totalAmount} -- OVER 35 POINTS [YOU WIN!]")
        elif totalAmount <= 35 and numberOne == 2:
            print("+10 Bonus for snake eyes [1][1]!")
            totalAmount = totalAmount + 10
            if totalAmount > 35:
                print(f"Total {totalAmount} -- OVER 35 POINTS [YOU WIN!]")
            elif totalAmount <= 35:
                print(f"Total {totalAmount} -- TOO FEW POINTS [YOU LOSE!]")
        answer = str(input("Enter 'Y' to play again: ").strip().upper())



def task4():
    def countCases(userString):
        stringLength = len(userString)
        upperCases = 0
        lowerCases = 0

        # The loop runs for every character and counts the upper cases and lower cases
        for i in range(0, stringLength):
            if userString[i].isupper():
                upperCases = upperCases + 1
            elif userString[i].islower():
                lowerCases = lowerCases + 1
        return upperCases, lowerCases

    def flipCase(userString):
        newString = str("")
        stringLength = len(userString)

        # The loop runs for every character and returns a new string where the cases of the string are swapped
        for i in range(0, stringLength):
            if userString[i].isupper():
                newString = newString + userString[i].lower()
            elif userString[i].islower():
                newString = newString + userString[i].upper()
            elif userString[i] == " ":
                newString = newString + " "
            elif userString[i] == "\"":
                newString = newString + "\""
        return newString

    def cutQuotedText(userString):
        noOfQuotes = 0
        newString = str("")
        stringLength = len(userString)

        # The loop removes all characters within the quotes, including the quotes.
        for i in range(0, stringLength):
            if userString[i] == "\"":
                noOfQuotes = noOfQuotes + 1

        if noOfQuotes > 2 or noOfQuotes == 0:
            return "ERROR! No quoted text."
        elif noOfQuotes == 2:
            # finding the first quote in the string
            firstQuote = userString.find("\"")
            newString = userString[firstQuote + 1:]
            # finding the second quote in the string
            secondQuote = newString.find("\"")
            secondQuote = firstQuote + secondQuote + 2
            # removing the word with quotes
            removedWord = userString[firstQuote : secondQuote]
            userString = userString.replace(removedWord, "")
            return userString

    # main program
    userInput = input("Enter string with one word with \"quotes\": ")
    upperCase, lowerCase = countCases(userInput)
    caseFlipped = flipCase(userInput)
    quotesRemoved = cutQuotedText(userInput)
    print(f"This string has {upperCase} uppercase characters.")
    print(f"This string has {lowerCase} lowercase characters.")
    print(f"Case flip: '{caseFlipped}'")
    print(f"Quote removed: '{quotesRemoved}'")


# main function for EECS1015 midterm
def main():
    print("\n")
    task0()
    print("\n----------Task 1-----------")
    task1()
    print("\n----------Task 2-----------")
    task2()
    print("\n----------Task 3-----------")
    task3()
    print("\n----------Task 4-----------")
    task4()
    input("\nPress enter to exit.")


if __name__ == "__main__":
    main()
