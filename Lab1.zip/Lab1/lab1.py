# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


# Lab 1
# Name: Atmiya Jadvani
# Email: atmiya@my.yorku.ca
# Student ID: 219164888
# Section A

print("My name is Atmiya Jadvani")
print("My York student ID is 219164888")
print("I'm in Section A.")
print("I currently live in Toronto,Canada\n")

# Asking user for the input in CAD
CAD = float(input("Enter amount in Canadian Dollars: "))

# Calculating in different currencies
USD = CAD * 0.794075
print("Amount in USD: ", USD)
# print(USD)

RMB = CAD * 5.141496
print("Amount in RMB: ", RMB)
# print(RMB)

EUR = CAD * 0.670762
print("Amount in EUR: ", EUR)
# print(EUR)

GBP = CAD * 0.575694
print("Amount in GBP: ", GBP)
# print(GBP)

INR = CAD * 58.14920
print("Amount in INR: ", INR)
# print(INR)

EGP = CAD * 12.50795
print("Amount in EGP: ", EGP)
# print(EGP)

PHP = CAD * 39.64959
print("Amount in PHP: ", PHP)
# print(PHP)

input("Press enter to end")
