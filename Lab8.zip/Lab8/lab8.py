# EECS Lab 8
# Author: Atmiya Jadvani
# Email: atmiya@my.yorku.ca
# Student ID: 219164888
# Section A

import random
import time

class Snail:

    # Snails
    sequence = ["__~@", "_~_@", "~__@"]

    # Constructor Functions
    def __init__(self, name):
        self.name = name.upper()
        assert len(self.name) == 2, "Snail's initials must be 2 characters"
        self.speed = (random.randint(1, 10)) / 10
        self.frame = 0
        self.pos = 0

    # Method to move the snal
    def move(self):
        self.pos = self.pos + self.speed
        self.frame = (self.frame + 1) % 3

    # Method to get position as integer
    def getIntPos(self):
        return int(self.pos)

    # Method to get name of the snail
    def getName(self):
        return self.name

    # Method to get race string of snail
    def getStr(self):
        animation = (" " * self.getIntPos())
        animation = animation + Snail.sequence[self.frame]
        animation = animation + (" " * (40 - self.getIntPos()))
        animation = animation + self.getName()
        return animation

# Function to get snail's list
def getSnailList():
    listOfSnailObjects = []
    N = int(input("How many snails are racing?: "))
    for i in range(1, N+1):
        twoInitials = input(f"Snail {i} two initials: ")
        listOfSnailObjects.append(Snail(twoInitials))
    return listOfSnailObjects

# Function to conduct the snail race
def runRace(snails):
    pressEnter = input("Press enter to start the race")
    currentTimeStep = 1

    # Run Race Loop
    while True:
        currentTime = (40 * "-") + "Time " + str(currentTimeStep)
        print(currentTime)
        for snail in snails:
            print(snail.getStr())
            snail.move()
            pos = snail.getIntPos()
            if pos > 39:
                print("Snail " + snail.getName() + " WON!")
                return

        time.sleep(0.2)
        currentTimeStep = currentTimeStep + 1

# MAIN CODE
playAgain = "Y"
while playAgain == "Y":
    print("Snail Race . . .")
    newSnails = getSnailList()
    runRace(newSnails)
    playAgain = input("Play again (Y): ").upper().strip()











