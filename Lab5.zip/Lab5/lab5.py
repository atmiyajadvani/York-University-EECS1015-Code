#########################
# EECS1015 - Lab 5
# Name: Atmiya Jadvani
# Student ID: 219164888
# Email: atmiya@my.yorku.ca
# Section A
#########################

import random


def task1():
    stringList = []

    def generateRandomList(listSize, maximumInteger):

        # generate a list of random integers and returns a list
        for i in range(0, listSize):
            randomNumber = random.randint(0, maximumInteger)
            stringList.append(randomNumber)
        print(stringList)
        return stringList

    def computeAverage(stringList):

        # return the average value of all the elements
        sumOfIntegers = 0
        noOfIntegers = len(stringList)
        for i in range(0, len(stringList)):
            sumOfIntegers = sumOfIntegers + stringList[i]
        listAverage = float(sumOfIntegers / noOfIntegers)
        print(f"Average value = {listAverage:.4f}")

    sizeOfList = int(input("Input list size: ").strip())
    maxInt = int(input("Input max int: ").strip())
    print("Generated List")
    generateRandomList(sizeOfList, maxInt)
    computeAverage(stringList)


def task2():
    stringList = []
    wordList = []

    # return a list with each number from the phone number
    def stringToCharLst(inputString):
        for i in range(len(inputString)):
            stringList.append(inputString[i])
        return stringList

    # returns a list with numbers converted to words
    def charsToWord(someList):
        numberDict = {'0': 'zero', '1': 'one', '2': 'two', '3': 'three', '4': 'four', '5': 'five', '6': 'six',
                      '7': 'seven', '8': 'eight', '9': 'nine', '-': 'dash'}
        for items in someList:
            wordList.append(numberDict[items])
        return wordList

    phoneNumber = input("Enter phone number as XXX-XXX-XXXX \nType here: ")
    stringList = stringToCharLst(phoneNumber)
    print(stringList)
    theOtherList = charsToWord(stringList)
    print(theOtherList)

    # Prints the list with the separator '->'
    separator = "->"
    uniqueList = separator.join(wordList)
    print(uniqueList)


# Main program starts here

def main():
    print("\n--------- TASK 1: Random List -------------")
    task1()
    print("\n--------- TASK 2: Phone number to text ---")
    task2()

    input("Press enter to exit.")


if __name__ == "__main__":
    main()
